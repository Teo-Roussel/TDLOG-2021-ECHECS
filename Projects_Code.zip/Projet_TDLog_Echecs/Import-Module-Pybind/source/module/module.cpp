#include <pybind11/pybind11.h>
#include <pybind11/operators.h>
#include <pybind11/stl.h>
#include <pybind11/functional.h>
#include <pybind11/stl_bind.h>



#include <functional>
#include <iostream>

#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <map>
#include <vector>

PYBIND11_MAKE_OPAQUE(std::vector<int>);

#include <piece.h>
#include <piece.cpp>
#include <damier.h>
#include <damier.cpp>
#include <engine.h>
#include <engine.cpp>


void fonction_test() {
	std::cout << "Salut, je suis la fonction test" << std::endl;
	std::cout << "SALUT COUCOU" << std::endl;
	Piece test_piece("roi", true);
	Damier test_damier("3r1r1k/3R3p/b3pppQ/4p3/p3P3/P7/2B3PP/5RK1 b - - 0 26");
	cout << test_damier.generateFEN() << endl;
	test_damier.display();
	//vector<int> pos_ini(1,42);
	//vector<int> pos_fin(1, -42);
	//vector<int> prom(1, -42);
	//alpha_beta_exploration(test_damier, pos_ini, pos_fin, prom, 5);
	//cout << "Mouvement de " << pos_ini[0] << " en " << pos_fin[0] << " avec transfo : " << prom[0] << endl;


	std::cout << test_piece << std::endl;
	std::cout << "coiiji" << std::endl;
}

struct Data_exemple {
	float x, y;
	Data_exemple() : x(0), y(0) {}
	Data_exemple(float _x, float _y) : x(_x), y(_y) {}

	void display() { std::cout << x << " " << y << std::endl; }
};

PYBIND11_MODULE(moduleAI, module)
{
	module.doc() = "Documentation";
	module.def("fonction_test", &fonction_test);

	// on lie les diff�rents type de vecteur gr�ce au header de pybind11
	// cela est obligatoire car on a des objets pass�s en r�f�rence dans des fonctions
	// si on le voulait, pour des classes non classiques, on pourrait recoder nous-m�me ces 'bind'
	pybind11::bind_vector<std::vector<int>>(module, "VectorInt");

	// c'est un template
	pybind11::class_<Data_exemple>(module, "Data_EXEMPLE")
		.def(pybind11::init<>())
		.def(pybind11::init<float, float>(), "constructeur 2", pybind11::arg("x"), pybind11::arg("y"))
		.def("display", &Data_exemple::display)
		.def_readwrite("x", &Data_exemple::x)
		.def_readwrite("y", &Data_exemple::y)		
	;

	pybind11::class_<Piece>(module, "Piece")
		.def(pybind11::init<>())
		.def(pybind11::init<std::string, bool>(), "constructeur 2", pybind11::arg("piece_name"), pybind11::arg("is_white"))
		.def("getName", &Piece::getName)
		.def("isWhite", &Piece::isWhite)
		.def("getId", &Piece::getId)
	
		.def(pybind11::self == pybind11::self)
		.def(pybind11::self != pybind11::self)		
		.def_property_readonly("name", &Piece::getName)
		.def_property_readonly("Id", &Piece::getId)
		.def_property_readonly("is_white", &Piece::isWhite)

		.def("__repr__", [](const Piece& p) { return "pybind11module.Piece named " + ((p.getName() == "vide") ? "vide" : (p.isWhite() ? (p.getName() + " Blanc") : (p.getName() + " Noir"))); })
		.def("__str__", [](const Piece& p) { return ((p.getName() == "vide") ? "    v    " : (p.isWhite() ? (p.getName() + " Blanc") : (p.getName() + " Noir"))); })
	;	

	pybind11::class_<Damier>(module, "Damier")
		.def(pybind11::init<>())		
		.def(pybind11::init<std::string>(), "constructeur 3", pybind11::arg("damier_fen"))
		.def("__call__", &Damier::operator())
		.def("display", &Damier::display)
		.def("setPieceOnSquare", &Damier::setPieceOnSquare, pybind11::arg("pos"), pybind11::arg("piece"))
		.def("isCastle", &Damier::isCastle, pybind11::arg("side"), pybind11::arg("is_player_white"))
		.def("forbidCastle", &Damier::forbidCastle, pybind11::arg("side"), pybind11::arg("is_player_white"))
		.def("allowCastle", &Damier::allowCastle, pybind11::arg("side"), pybind11::arg("is_player_white"))
		.def("getPlayerTurn", &Damier::getPlayerTurn)
		.def("isPieceEmpty", &Damier::isPieceEmpty, pybind11::arg("pos"))

		// rajouter les is_attacked ?
		.def("is_king_attacked", &Damier::is_king_attacked)

		.def("mvt_tour", &Damier::mvt_tour, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"))
		.def("mvt_fou", &Damier::mvt_fou, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"))
		.def("mvt_cavalier", &Damier::mvt_cavalier, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"))
		.def("mvt_dame", &Damier::mvt_dame, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"))
		.def("mvt_roi", &Damier::mvt_roi, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"), pybind11::arg("callIs_attacked"))
		.def("mvt_pion", &Damier::mvt_pion, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"))
		

		.def("movement_piece", &Damier::movement_piece, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("prom_vect"), pybind11::arg("callIs_attacked"))
		.def("player_possible_movements", &Damier::player_possible_movements, pybind11::arg("is_player_white"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("prom_vect"), pybind11::arg("callIs_attacked"))
		.def("bouge_piece", &Damier::bouge_piece, pybind11::arg("pos_ini"), pybind11::arg("pos_fin"), pybind11::arg("promotion"))


		.def("add_move_to_stack", &Damier::add_move_to_stack, pybind11::arg("pos_ini"), pybind11::arg("pos_fin"), pybind11::arg("nbr_moves"))
		.def("undo_move", &Damier::undo_move)
		.def("generate_FEN", &Damier::generateFEN)
	;

	module.def("evaluate_bonus_malus", &evaluate_bonus_malus, pybind11::arg("chessboard"), pybind11::arg("is_player_white"));
	module.def("alpha_beta_exploration", &alpha_beta_exploration, pybind11::arg("chessboard"), pybind11::arg("pos_ini"), pybind11::arg("pos_fin"), pybind11::arg("promotion"), pybind11::arg("depth"));

	
}


