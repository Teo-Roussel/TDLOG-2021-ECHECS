#ifndef PIECE_H
#define PIECE_H



#include <map>
#include <vector>
//#include <pybind11/pybind11.h>
//#include <pybind11/stl.h>
//#include <pybind11/numpy.h>
#include <iostream>
using namespace std;

static std::string const name_array[7] = {"tour", "cavalier", "fou", "dame", "roi", "pion", "vide"};
// une pièce est juste définie par son numéro
// et un damier vide = pas de pi

std::map<string, int> init_mapOfValues();
static const std::map<std::string, int> mapOfValues = init_mapOfValues();

std::map<int, int> init_mapOfValues_();
static const std::map<int, int> mapOfValues_ = init_mapOfValues_();


class Piece{
    int id;
    bool is_white;

public:

    Piece();
    Piece(const int piece_id, const bool player_color = true);
    Piece(const string name, const bool player_color = true);
    std::string getName() const;
    bool isWhite() const;
    int getId() const;


    bool operator==(const Piece& piece) const;
    bool operator!=(const Piece& piece) const;
    friend std::ostream & operator << (std::ostream &out, const Piece &piece);
};

std::ostream & operator<<(std::ostream &out, const Piece &obj);

#endif // PIECE_H
