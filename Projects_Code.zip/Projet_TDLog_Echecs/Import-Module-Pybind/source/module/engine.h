#ifndef ENGINE_H
#define ENGINE_H
#pragma once

#include "piece.h"
#include "damier.h"
#include <unordered_map>



class NodeInformation{
    int depth;
    int value;
    std::string flag;
public:
    NodeInformation();
    NodeInformation(int new_depth, int new_value, std::string flag);
    int getDepth();
    int getValue();
    std::string getFlag();
};

int evaluate_bonus_malus(const Damier& chessboard, const bool is_player_white);
int evaluateNegaMax(const Damier &chessboard, const bool is_player_white);
void algoNegaMax(Damier &chessboard, int& pos_ini, int& pos_fin, int &promotion, int depth);
int algoNegaMax_aux(Damier &chessboard, int depth, int &nbr_iter);


void alpha_beta_exploration(Damier& chessboard, vector<int> &pos_ini, vector<int> &pos_fin, vector<int> &promotion, const int depth);
int alpha_beta_exploration_aux(Damier& chessboard, const int depth, int alpha, int beta, int &nbr_iter);

void algoNegaMax_alpha_beta(Damier &chessboard, int& pos_ini, int& pos_fin, string& promotion, const int depth);
int algoNegaMax_alpha_beta_aux(Damier &chessboard, const int depth, int alpha, int beta, unordered_map<string, NodeInformation> &transposition_table, int &nbr_iter);

int evaluateMinMax(const Damier &chessboard);
//void algoMinMax_deuxieme(Damier &chessboard, int& pos_ini, int& pos_fin, string &promotion, int depth);
//int algoMinMax_aux_deuxieme(Damier &chessboard, int depth, Color original_player);

#endif // ENGINE_H
