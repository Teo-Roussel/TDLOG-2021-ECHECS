#ifndef DAMIER_H
#define DAMIER_H
#pragma once

#include "piece.h"

#include <stack>
#include <algorithm>

const int width = 8; // les indices i
const int length = 8; // les indices j


void convert(const int n, const int width, int& i, int &j);


class Damier{
    Piece p_array[width*length];    

    bool player_who_play_is_white = true;
    int half_move = 0;
    int full_move = 1;

    bool castle_array[4] = {true, true, true, true};
//    0 -> gauche noir
//    1 -> droite noir
//    2 -> gauche blanc
//    3 -> droite blanc
    std::stack<int> s_pos_ini;
    std::stack<int> s_pos_fin;
    std::stack<Piece> s_piece_moved;
    std::stack<Piece> s_piece_erased;
    std::stack<int> s_nbr_elem_back; // 2 si roque, 1 sinon
    std::stack<int> s_half_move;

    std::stack<bool> s_castle_lb;
    std::stack<bool> s_castle_rb;
    std::stack<bool> s_castle_lw;
    std::stack<bool> s_castle_rw;

public:

    Damier();
    Damier(const std::string& damier_fen);
    Piece operator()(const int pos) const;

    void display() const;

    void setPieceOnSquare(const int pos, const Piece p);

//    bool isCastle(const std::string& side, const bool is_player_white) const;
//    void forbidCastle(const std::string& side, const bool is_player_white);
//    void allowCastle(const std::string& side, const bool is_player_white);

    bool isCastle(const bool is_side_left, const bool is_player_white) const;
    void forbidCastle(const bool is_side_left, const bool is_player_white);
    void allowCastle(const bool is_side_left, const bool is_player_white);

    bool getPlayerTurn() const;
    int getNbrFullMove() const;

    //bool isPieceEmpty(const int& i, const int& j) const;
    /**
     * @brief isPieceEmpty
     * @param pos : compris dans [0,width*length[
     * @return
     */
    bool isPieceEmpty(const int pos) const;


    // ===================   
    bool is_attacked(int* positions, const int nbr_positions, const vector<int>& adv_pos_fin) const;
    bool is_attacked(const int pos, const vector<int>& adv_pos_fin) const;
    bool is_king_attacked(const bool is_player_white); // renvoie un booleen indiquant si le roi de la couleur du plateau est en échec ou pas

//    void mvt_tour(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<std::string>& promotion_vect) const;
//    void mvt_fou(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<std::string>& promotion_vect) const;
//    void mvt_cavalier(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<std::string>& promotion_vect) const;
//    void mvt_dame(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<std::string>& promotion_vect) const;
//    void mvt_roi(const int pos,vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<std::string>& promotion_vect, const bool callIs_attacked) const;
//    void mvt_pion(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<std::string>& promotion_vect) const;
//    void movement_piece(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<std::string>& promotion_vect, const bool callIs_attacked) const;
//    void player_possible_movements(const bool is_player_white, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<std::string>& promotion_vect, const bool callIs_attacked = true) const;
//    bool bouge_piece(const int pos_ini, const int pos_fin, const string &promotion);

    void mvt_tour(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<int>& promotion_vect) const;
    void mvt_fou(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<int>& promotion_vect) const;
    void mvt_cavalier(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<int>& promotion_vect) const;
    void mvt_dame(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<int>& promotion_vect) const;
    void mvt_roi(const int pos,vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<int>& promotion_vect, const bool callIs_attacked) const;
    void mvt_pion(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<int>& promotion_vect) const;

    /**
     * @brief movement_piece : determine quelle fonction doit etre appelee en fonction de la piece a la case (i,j)
     * @param i
     * @param j
     * @param movement_vector
     */
    void movement_piece(const int pos, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<int>& promotion_vect, const bool callIs_attacked) const;
    void player_possible_movements(const bool is_player_white, vector<int>& pos_ini_vect, vector<int>& pos_fin_vect, vector<int>& promotion_vect, const bool callIs_attacked = true) const;
    bool bouge_piece(const int pos_ini, const int pos_fin, const int promotion);

//    bool isGameFinished(int& end_type);

    void add_move_to_stack(const int pos_ini, const int pos_fin, int& nbr_moves);
    void undo_move();

    string generateFEN();
};


void display_array_64();
void display_array_120();
void push_multiple_elem(const int& v1, vector<int>& vect1, const int& v2, vector<int>& vect2, const string& string_value, vector<std::string>& vect3);
void push_multiple_elem(const int& v1, vector<int>& vect1, const int& v2, vector<int>& vect2, const int v3, vector<int>& vect3);



#endif // DAMIER_H
