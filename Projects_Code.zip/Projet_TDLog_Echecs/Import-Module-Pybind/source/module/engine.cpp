#include "engine.h"
#include "piece.h"
#include "damier.h"

#include <ctime>

using namespace std;

NodeInformation::NodeInformation(){/*cout<<"couc"<<endl;*/}

NodeInformation::NodeInformation(int new_depth, int new_value, string new_flag){
    depth = new_depth;
    value = new_value;
    flag = new_flag;
}

int NodeInformation::getDepth(){return depth;}
int NodeInformation::getValue(){return value;}
string NodeInformation::getFlag(){return flag;}

// =========| Tableaux des bonus et malus pour les pieces blanches |===============

static const int white_pawn_values[64] = { 0, 0, 0, 0, 0, 0, 0, 0,
                                    50, 50, 50, 50, 50, 50, 50, 50,
                                    10, 10, 20, 30, 30, 20, 10, 10,
                                    5, 5, 10, 25, 25, 10, 5, 5,
                                    0, 0, 0, 20, 20, 0, 0, 0,
                                    5, -5, -10, 0, 0, -10, -5, 5,
                                    5, 10, 10, -20, -20, 10, 10, 5,
                                    0, 0, 0, 0, 0, 0, 0, 0
};

static const int white_knight_values[64] = { -50, -40, -30, -30, -30, -30, -40, -50,
                                      -40, -20, 0, 0, 0, 0, -20, -40,
                                      -30, 0, 10, 15, 15, 10, 0, -30,
                                      -30, 5, 15, 20, 20, 15, 5, -30,
                                      -30, 0, 15, 20, 20, 15, 0, -30,
                                      -30, 5, 10, 15, 15, 10, 5, -30,
                                      -40, -20, 0, 5, 5, 0, -20, -40,
                                      -50, -40, -30, -30, -30, -30, -40, -50
};

static const int white_bishop_values[64] = { -20, -10, -10, -10, -10, -10, -10, -20,
                                      -10, 0, 0, 0, 0, 0, 0, -10,
                                      -10, 0, 5, 10, 10, 5, 0, -10,
                                      -10, 5, 5, 10, 10, 5, 5, -10,
                                      -10, 0, 10, 10, 10, 10, 0, -10,
                                      -10, 10, 10, 10, 10, 10, 10, -10,
                                      -10, 5, 0, 0, 0, 0, 5, -10,
                                      -20, -10, -10, -10, -10, -10, -10, -20
};

static const int white_rook_values[64] = { 0, 0, 0, 0, 0, 0, 0, 0,
                                    5, 10, 10, 10, 10, 10, 10, 5,
                                    -5, 0, 0, 0, 0, 0, 0, -5,
                                    -5, 0, 0, 0, 0, 0, 0, -5,
                                    -5, 0, 0, 0, 0, 0, 0, -5,
                                    -5, 0, 0, 0, 0, 0, 0, -5,
                                    -5, 0, 0, 0, 0, 0, 0, -5,
                                    0, 0, 0, 5, 5, 0, 0, 0
};

static const int white_queen_values[64] = { -20, -10, -10, -5, -5, -10, -10, -20,
                                     -10, 0, 0, 0, 0, 0, 0, -10,
                                     -10, 0, 5, 5, 5, 5, 0, -10,
                                     -5, 0, 5, 5, 5, 5, 0, -5,
                                     0, 0, 5, 5, 5, 5, 0, -5,
                                     -10, 5, 5, 5, 5, 5, 0, -10,
                                     -10, 0, 5, 0, 0, 0, 0, -10,
                                     -20, -10, -10, -5, -5, -10, -10, -20
};

static const int white_king_values_middle_game[64] = { -30, -40, -40, -50, -50, -40, -40, -30,
                                                -30, -40, -40, -50, -50, -40, -40, -30,
                                                -30, -40, -40, -50, -50, -40, -40, -30,
                                                -30, -40, -40, -50, -50, -40, -40, -30,
                                                -20, -30, -30, -40, -40, -30, -30, -20,
                                                -10, -20, -20, -30, -30, -20, -20, -10,
                                                20, 20, 0, 0, 0, 0, 20, 20,
                                                20, 30, 10, 0, 0, 10, 30, 20
};

static const int white_king_values_end_game[64] = { -50, -40, -30, -20, -20, -30, -40, -50,
                                                -30, -20, -10, 0, 0, -10, -20, -30,
                                                -30, -10, 20, 30, 30, 20, -10, -30,
                                                -30, -10, 30, 40, 40, 30, -10, -30,
                                                -30, -10, 30, 40, 40, 30, -10, -30,
                                                -30, -10, 20, 30, 30, 20, -10, -30,
                                                -30, -30, 0, 0, 0, 0, -30, -30,
                                                -50, -30, -30, -30, -30, -30, -30, -50
};

// =========| Tableaux des bonus et malus pour les pieces noires |===============

static const int black_pawn_values[64] = { 0, 0, 0, 0, 0, 0, 0, 0,
                                    5, 10, 10, -20, -20, 10, 10, 5,
                                    5, -5, -10, 0, 0, -10, -5, 5,
                                    0, 0, 0, 20, 20, 0, 0, 0,
                                    5, 5, 10, 25, 25, 10, 5, 5,
                                    10, 10, 20, 30, 30, 20, 10, 10,
                                    50, 50, 50, 50, 50, 50, 50, 50,
                                    0, 0, 0, 0, 0, 0, 0, 0
};

static const int black_knight_values[64] = { -50, -40, -30, -30, -30, -30, -40, -50,
                                      -40, -20, 0, 5, 5, 0, -20, -40,
                                      -30, 5, 10, 15, 15, 10, 5, -30,
                                      -30, 0, 15, 20, 20, 15, 0, -30,
                                      -30, 5, 15, 20, 20, 15, 5, -30,
                                      -30, 0, 10, 15, 15, 10, 0, -30,
                                      -40, -20, 0, 0, 0, 0, -20, -40,
                                      -50, -40, -30, -30, -30, -30, -40, -50
};

static const int black_bishop_values[64] = { -20, -10, -10, -10, -10, -10, -10, -20,
                                      -10, 5, 0, 0, 0, 0, 5, -10,
                                      -10, 10, 10, 10, 10, 10, 10, -10,
                                      -10, 0, 10, 10, 10, 10, 0, -10,
                                      -10, 5, 5, 10, 10, 5, 5, -10,
                                      -10, 0, 5, 10, 10, 5, 0, -10
                                      - 10, 0, 0, 0, 0, 0, 0, -10,
                                      -20, -10, -10, -10, -10, -10, -10, -20
};

static const int black_rook_values[64] = { 0, 0, 0, 5, 5, 0, 0, 0,
                                    -5, 0, 0, 0, 0, 0, 0, -5,
                                    -5, 0, 0, 0, 0, 0, 0, -5,
                                    -5, 0, 0, 0, 0, 0, 0, -5,
                                    -5, 0, 0, 0, 0, 0, 0, -5,
                                    -5, 0, 0, 0, 0, 0, 0, -5,
                                    5, 10, 10, 10, 10, 10, 10, 5,
                                    0, 0, 0, 0, 0, 0, 0, 0
};


static const int black_queen_values[64] = { -20, -10, -10, -5, -5, -10, -10, -20,
                                     -10, 0, 0, 0, 0, 5, 0, -10,
                                     -10, 0, 5, 5, 5, 5, 5, -10,
                                     0, 0, 5, 5, 5, 5, 0, -5,
                                     -5, 0, 5, 5, 5, 5, 0, -5,
                                     -10, 0, 5, 5, 5, 5, 0, -10,
                                     -10, 0, 0, 0, 0, 0, 0, -10,
                                     -20, -10, -10, -5, -5, -10, -10, -20
};

static const int black_king_values_middle_game[64] = { 20, 30, 10, 0, 0, 10, 30, 20,
                                                20, 20, 0, 0, 0, 0, 20, 20,
                                                -10, -20, -20, -30, -30, -20, -20, -10,
                                                -20, -30, -30, -40, -40, -30, -30, -20,
                                                -30, -40, -40, -50, -50, -40, -40, -30,
                                                -30, -40, -40, -50, -50, -40, -40, -30,
                                                -30, -40, -40, -50, -50, -40, -40, -30,
                                                -30, -40, -40, -50, -50, -40, -40, -30
};

static const int black_king_values_end_game[64] = { -50, -30, -30, -30, -30, -30, -30, -50,
                                             -30, -30, 0, 0, 0, 0, -30, -30,
                                             -30, -10, 20, 30, 30, 20, -10, -30,
                                             -30, -10, 30, 40, 40, 30, -10, -30,
                                             -30, -10, 30, 40, 40, 30, -10, -30,
                                             -30, -10, 20, 30, 30, 20, -10, -30,
                                             -30, -20, -10, 0, 0, -10, -20, -30,
                                             -50, -40, -30, -20, -20, -30, -40, -50
};


// =================| Fonctions pour l'IA |=======================

int evaluateNegaMax(const Damier &chessboard, const bool is_player_white){
    int white_score = 0;
    int black_score = 0;
    // ==================| Calcul des valeurs de chaque joueur |==================
    for (int pos = 0; pos < width*length; pos++)
    {
        if (chessboard(pos).isWhite())
            white_score += mapOfValues_.at(chessboard(pos).getId());
        else // on compte aussi les cases vides, mais elles valent 0
            black_score += mapOfValues_.at(chessboard(pos).getId());
    }    
    if (is_player_white)
        return white_score - black_score;
    else if (!is_player_white)
        return black_score - white_score;
    else
        throw "la couleur entree n'est pas bonne";
}


int evaluate_bonus_malus(const Damier& chessboard, const bool is_player_white) {
    static const int fin_de_partie = 20;
    int white_score = 0;
    int black_score = 0;
    // ==================| Calcul des valeurs de chaque joueur |==================
    for (int pos = 0; pos < width * length; pos++)
    {
        int current_id = chessboard(pos).getId();
        if (current_id == 6)
            continue;

        if (chessboard(pos).isWhite())
        {
            white_score += mapOfValues_.at(current_id);
            if (current_id == 5)
                white_score += white_pawn_values[pos];
            else if (current_id == 1)
                white_score += white_knight_values[pos];
            else if (current_id == 2)
                white_score += white_bishop_values[pos];
            else if (current_id == 0)
                white_score += white_rook_values[pos];
            else if (current_id == 3)
                white_score += white_queen_values[pos];
            else if (current_id == 4 && chessboard.getNbrFullMove() < fin_de_partie)
                white_score += white_king_values_middle_game[pos];
            else if (current_id == 4 && chessboard.getNbrFullMove() >= fin_de_partie)
                white_score += white_king_values_end_game[pos];
            else
                throw "Probleme dans le calcul du score";
        }
        else
        {
            black_score += mapOfValues_.at(current_id);
            if (current_id == 5)
                black_score += black_pawn_values[pos];
            else if (current_id == 1)
                black_score += black_knight_values[pos];
            else if (current_id == 2)
                black_score += black_bishop_values[pos];
            else if (current_id == 0)
                black_score += black_rook_values[pos];
            else if (current_id == 3)
                black_score += black_queen_values[pos];
            else if (current_id == 4 && chessboard.getNbrFullMove() < fin_de_partie)
                black_score += black_king_values_middle_game[pos];
            else if (current_id == 4 && chessboard.getNbrFullMove() >= fin_de_partie)
                black_score += black_king_values_end_game[pos];
            else
                throw "Probleme dans le calcul du score";
        }
    }
    if (is_player_white)
        return white_score - black_score;
    else
        return black_score - white_score;    
}

void algoNegaMax(Damier &chessboard, int &pos_ini, int &pos_fin, int &promotion, int depth){

    vector<int> pos_ini_vect;
    vector<int> pos_fin_vect;
    vector<int> promotion_vect;
    chessboard.player_possible_movements(chessboard.getPlayerTurn(), pos_ini_vect, pos_fin_vect, promotion_vect, true);
    int val = -1000;
    int nbr_iter = 0;

    for (unsigned int k = 0; k < pos_ini_vect.size(); k++)
    {

        chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k]);
        //cout << ">>>>>J'appelle pour le mouvement : " << pos_ini_vect[k] << " qui va a : " << pos_fin_vect[k] <<endl;

        int val_aux = algoNegaMax_aux(chessboard, depth-1, nbr_iter);
        if ( -val_aux > val)
        {
            pos_ini = pos_ini_vect[k];
            pos_fin = pos_fin_vect[k];
            promotion = promotion_vect[k];
            val = -val_aux;
        }

        //cout <<" ========| Fin d'un noeud haut |==============" << endl;
        chessboard.undo_move();
        nbr_iter++;
    }
    //cout << "la meilleure valeur est : "<<val << endl;
    cout << "nombre d'iterations : "<<nbr_iter<<endl;   
}



int algoNegaMax_aux(Damier &chessboard, int depth, int &nbr_iter){
    nbr_iter++;
    if (depth == 0){
        //int test = evaluateNegaMax(chessboard, (chessboard.getPlayerTurn() == WHITE) ? BLACK : WHITE);
        int test = evaluateNegaMax(chessboard, chessboard.getPlayerTurn());
        //car si on est là, c'est qu'on vient de bouger une piece de la couleur opposee a player_color
        //on veut donc connaitre la situation pour l'ancienne couleur, cad la couleur opposee de player_color

        //cout << "La valeur est : " << test << " et la couleur : "<< ((chessboard.getPlayerTurn() == WHITE) ? BLACK : WHITE)<< endl;
        //cout <<"========" << endl;

        return test;
    }
    else{
        vector<int> pos_ini_vect;
        vector<int> pos_fin_vect;
        vector<int> promotion_vect;
        chessboard.player_possible_movements(chessboard.getPlayerTurn(), pos_ini_vect, pos_fin_vect, promotion_vect, true);


        int val = -1000;
        for (unsigned int k = 0; k < pos_ini_vect.size(); k++)
        {
            chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k]);
            //cout << "J'appelle pour le mouvement : " << pos_ini_vect[k] << " qui va a : " << pos_fin_vect[k] <<endl;
            val = max(val, -algoNegaMax_aux(chessboard, depth-1, nbr_iter));
            chessboard.undo_move();
        }
       // cout<< ">>>>>>>>>>>>>>>>" << endl;
        return val;
    }
}


void alpha_beta_exploration(Damier& chessboard, vector<int> &pos_ini, vector<int> &pos_fin, vector<int> &promotion, const int depth){

    if (depth < 1) {
        throw "depth should be superior or equal to 1";
    }

    clock_t time1 = clock();

    int alpha = -40000;
    int beta = 40000;
    int value = -60000;
    vector<int> pos_ini_vect;
    vector<int> pos_fin_vect;
    vector<int> promotion_vect;
    chessboard.player_possible_movements(chessboard.getPlayerTurn(), pos_ini_vect, pos_fin_vect, promotion_vect, true);
    int nbr_iter = 0;

    //renvoyer 0 si aucun mouvement

    for (unsigned int k = 0; k < pos_ini_vect.size(); k++)
    {
        //int alpha_child = -beta;
        //int beta_child = -alpha;
        //mouvement
        nbr_iter++;
//        chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k]);
        if (!chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k])) // a voir si on peut pas le faire dans l'appel suivant
        {
            //nbr_iter++;
            chessboard.undo_move();
            continue;
        }

        int val_int = - alpha_beta_exploration_aux(chessboard, depth-1, -beta, -alpha, nbr_iter);
        chessboard.undo_move();

        //alpha = beta_child;
        //beta = alpha_child;

        if (val_int > value){            
            pos_ini[0] = pos_ini_vect[k];
            pos_fin[0] = pos_fin_vect[k];
            promotion[0] = promotion_vect[k];
            value = val_int;
        }
       
        if (value > alpha)
            alpha = value;
        if (value >= beta)
            break;
        /*
        if (value > alpha)
            alpha = value;
            */

        /*
        alpha = max(alpha, value);
        if (alpha >= beta)
            break;
            */
    }
    // ici rajouter la détection du echec et mat
    //SI AUCUN move valide et echec, on met pos_ini et pos_fin à -1 ?
    // SI PAT, on met pos_ini et pos_fin à -2 ?

    // Finalement, après discussion, cette fonction est appelée si au moins un des moves est valide.

    clock_t time2 = clock();
    
    cout << "score debut : " << evaluate_bonus_malus(chessboard,chessboard.getPlayerTurn()) << endl;
    cout << "meilleure valeur : " << alpha << endl;
    cout << "nombre d'iterations : "<<nbr_iter<<endl;   
    cout << "Temps d'execution : " << (float(time2 - time1) / CLOCKS_PER_SEC) << endl;
    
}


int alpha_beta_exploration_aux(Damier& chessboard, const int depth, int alpha, int beta, int& nbr_iter){    

    nbr_iter++;
    if (depth == 0)
        //return evaluateNegaMax(chessboard, chessboard.getPlayerTurn());
        return evaluate_bonus_malus(chessboard, chessboard.getPlayerTurn());

    int value = -60000;
    vector<int> pos_ini_vect;
    vector<int> pos_fin_vect;
    vector<int> promotion_vect;
    chessboard.player_possible_movements(chessboard.getPlayerTurn(), pos_ini_vect, pos_fin_vect, promotion_vect, true);

    bool valid_move_exist = false;
    for (unsigned int k = 0; k < pos_ini_vect.size(); k++)
    {
        //int alpha_child = -beta;
        //int beta_child = -alpha;

//        chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k]);
        if (!chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k])) // a voir si on peut pas le faire dans l'appel suivant
        {
            //nbr_iter++;
            chessboard.undo_move();
            continue;
        }
        valid_move_exist = true;

        value = max(value, -alpha_beta_exploration_aux(chessboard, depth-1, -beta, -alpha, nbr_iter));
        //value = -alpha_beta_exploration_aux(chessboard, depth - 1, -beta, -alpha, nbr_iter);
        chessboard.undo_move();
        //alpha = beta_child;
        //beta = alpha_child;
        /*
        if (value >= beta)
            return beta;
        if (value > alpha)
            alpha = value;
            */
        alpha = max(alpha, value);
        if (alpha >= beta)
            break;
        /*
        if (alpha >= beta)
            return beta;   
            */

        /*
        alpha = max(alpha, value);
        if (alpha >= beta)
            break;
            */

    }
    
    if (!valid_move_exist)
    {
       /*
        cout << "" << endl;
        cout << "" << endl;
        cout << "La profondeur est : " << depth << endl;
        chessboard.display();
        cout << "no valid move" << endl;
        //cout << alpha + evaluate_bonus_malus(chessboard, chessboard.getPlayerTurn()) << endl;
        cout << alpha * depth << endl;
        cout << beta << endl;
        cout << "" << endl;
        cout << "" << endl;
        */
             
        if (chessboard.is_king_attacked(chessboard.getPlayerTurn()))
        {
            /*
            cout << "" << endl;
            cout << "" << endl;
            cout << "La profondeur est : " << depth << endl;
            chessboard.display();
            cout << "no valid move" << endl;
            cout << alpha + evaluate_bonus_malus(chessboard, chessboard.getPlayerTurn()) << endl;
            cout << "" << endl;
            cout << "" << endl;
            */

            //return -10000; // valeur à modifier ? return alpha ? ou evaluate ?
            //return evaluate_bonus_malus(chessboard, chessboard.getPlayerTurn());
            //return alpha * depth;
            return evaluate_bonus_malus(chessboard, chessboard.getPlayerTurn()) * depth;
            //return alpha + evaluate_bonus_malus(chessboard, chessboard.getPlayerTurn());
        }
        else
            return 0; // égalité
    }
    
    // ici rajouter la détection du echec et mat

    //return alpha;
    return value;
}




void algoNegaMax_alpha_beta(Damier &chessboard, int& pos_ini, int& pos_fin, string& promotion, const int depth){
    int alpha = -40000;
    int beta = 40000;
    int alpha_origine = alpha;
    string chessboard_FEN = chessboard.generateFEN();
    unordered_map<string, NodeInformation> transposition_table;
    if (depth <= 0)
        throw "Depth should be superior to one";

    vector<int> pos_ini_vect;
    vector<int> pos_fin_vect;
    vector<int> promotion_vect;
    chessboard.player_possible_movements(chessboard.getPlayerTurn(), pos_ini_vect, pos_fin_vect, promotion_vect, true);
    int value = -40000;
    int nbr_iter = 0;

    for (unsigned int k = 0; k < pos_ini_vect.size(); k++)
    {
        nbr_iter++;
        chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k]); // on bouge la pièce
        int val_int = -algoNegaMax_alpha_beta_aux(chessboard, depth-1, -beta, -alpha, transposition_table, nbr_iter);
        chessboard.undo_move(); // on annule le mouvement

        if (val_int > value)
        {
            pos_ini = pos_ini_vect[k];
            pos_fin = pos_fin_vect[k];
            promotion = promotion_vect[k];
            value = val_int;
        }
        alpha = max(alpha, value);        

        if (alpha >= beta)
            break;
    }

    // creation de la nouvelle valeur stockee dans le dictionnaire, ou modification si deja existante
    string new_flag;
    if (value <= alpha_origine)
        new_flag = "UPPERBOUND";
    else if (value >= beta)
        new_flag = "LOWERBOUND";
    else
        new_flag = "EXACT";
    transposition_table[chessboard_FEN] = NodeInformation(depth, value, new_flag);

    cout << "meilleure valeur : " << value << endl;
    cout << "taille de la table de transposition : " << transposition_table.size() << endl;
    cout << "nombre d'iterations : "<<nbr_iter<<endl;    
}


int algoNegaMax_alpha_beta_aux(Damier &chessboard, const int depth, int alpha, int beta, unordered_map<string, NodeInformation> &transposition_table, int &nbr_iter){
    nbr_iter++;
    int alpha_origine = alpha;
    string chessboard_FEN = chessboard.generateFEN();

    if (transposition_table.count(chessboard_FEN) && transposition_table.at(chessboard_FEN).getDepth() >= depth)
    {
        //cout << chessboard_FEN << endl;
        //cout << transposition_table.size() << endl;

        NodeInformation current_node = transposition_table.at(chessboard_FEN);
        if (current_node.getFlag() == "EXACT")
            return current_node.getValue();
        else if (current_node.getFlag() == "LOWERBOUND")
            alpha = max(alpha, current_node.getValue());
        else if (current_node.getFlag() == "UPPERBOUND")
            beta = min(beta, current_node.getValue());

        if (alpha >= beta)
            return current_node.getValue();
    }

    if (depth == 0)
        return evaluateNegaMax(chessboard, chessboard.getPlayerTurn());

    // Pas besoin de else, car le if contient un return.
    vector<int> pos_ini_vect;
    vector<int> pos_fin_vect;
    vector<int> promotion_vect;
    chessboard.player_possible_movements(chessboard.getPlayerTurn(), pos_ini_vect, pos_fin_vect, promotion_vect, true);
    // generation des mouvements possibles

    int value = -40000;

    for (unsigned int k = 0; k < pos_ini_vect.size(); k++)
    {


        chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k]); // on bouge la piece
        value = max(value, -algoNegaMax_alpha_beta_aux(chessboard, depth-1, -beta, -alpha, transposition_table, nbr_iter));
        chessboard.undo_move(); //  on annule le mouvement
        alpha = max(alpha, value);

        if (alpha >= beta)
            break;
    }

    // creation de la nouvelle valeur stockee dans le dictionnaire, ou modification si deja existante
    string new_flag;
    if (value <= alpha_origine)
        new_flag = "UPPERBOUND";
    else if (value >= beta)
        new_flag = "LOWERBOUND";
    else
        new_flag = "EXACT";
    transposition_table[chessboard_FEN] = NodeInformation(depth, value, new_flag);

    return value;
}



















// ============| Algo MinMax |==================

int evaluateMinMax(const Damier &chessboard){
    int white_score = 0;
    int black_score = 0;
    // ==================| Calcul des valeurs de chaque joueur |==================
    for (int pos = 0; pos < width*length; pos++)
    {
        if (chessboard(pos).isWhite())
            white_score += mapOfValues.at(chessboard(pos).getName());
        else // on compte aussi les cases vides, mais elles valent 0
            black_score += mapOfValues.at(chessboard(pos).getName());
    }
    return white_score - black_score; // on renvoie une evaluation constante, et la discrimination se fait dans algoMinMax
}





//void algoMinMax_deuxieme(Damier &chessboard, int& pos_ini, int& pos_fin, string &promotion, int depth){
//    bool is_current_player_white = chessboard.getPlayerTurn();
//
//    //on maximise sur blanc
//    //on minimise sur noir
//
//    vector<int> pos_ini_vect;
//    vector<int> pos_fin_vect;
//    vector<string> promotion_vect;
//    chessboard.player_possible_movements(is_current_player_white, pos_ini_vect, pos_fin_vect, promotion_vect, true);
//
//    if (is_current_player_white)
//    {
//        int val = -1000;
//
//        for (unsigned int k = 0; k < pos_ini_vect.size(); k++ )
//        {
//            chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k]);
//            int val_aux = algoMinMax_aux_deuxieme(chessboard, depth-1, current_color);
//
//            if (val_aux > val)
//            {
//                pos_ini = pos_ini_vect[k];
//                pos_fin = pos_fin_vect[k];
//                promotion = promotion_vect[k];
//                val = val_aux;
//            }
//            chessboard.undo_move();
//        }
//        //for () val = max(val, appel)
//
//        cout << "meilleure valeur blanche : " << val << endl;
//    }
//    else //i.e. on est noir
//    {
//        int val = 1000;
//        for (unsigned int k = 0; k < pos_ini_vect.size(); k++)
//        {
//            chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k]);
//            int val_aux = algoMinMax_aux_deuxieme(chessboard, depth-1, current_color);
//
//            if (val_aux < val)
//            {
//                pos_ini = pos_ini_vect[k];
//                pos_fin = pos_fin_vect[k];
//                promotion = promotion_vect[k];
//                val = val_aux;
//            }
//            chessboard.undo_move();
//        }
//        cout << "meilleure valeur noire : " << val << endl;
//    }
//}
//
//
//
//int algoMinMax_aux_deuxieme(Damier &chessboard, int depth, Color original_player){
//    if (depth == 0)
//    {
//        return evaluateMinMax(chessboard);
//    }
//    else
//    {
//        Color current_color = chessboard.getPlayerTurn();
//
//        //on maximise sur blanc
//        //on minimise sur noir
//
//        vector<int> pos_ini_vect;
//        vector<int> pos_fin_vect;
//        vector<string> promotion_vect;
//        chessboard.player_possible_movements(current_color, pos_ini_vect, pos_fin_vect, promotion_vect, true);
//
//        if (current_color == WHITE)
//        {
//            int val = -1000;
//            for (int k = 0; k < pos_ini_vect.size(); k++)
//            {
//                chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k]);
//                // regarder
//                val = max(val, algoMinMax_aux_deuxieme(chessboard, depth-1, original_player));
//                chessboard.undo_move();
//            }
//            return val;
//        }
//        else //i.e. on est noir
//        {
//            int val = 1000;
//            for (int k = 0; k < pos_ini_vect.size(); k++)
//            {
//                chessboard.bouge_piece(pos_ini_vect[k], pos_fin_vect[k], promotion_vect[k]);
//                val = min(val, algoMinMax_aux_deuxieme(chessboard, depth-1, original_player));
//                chessboard.undo_move();
//            }
//            return val;
//        }
//    }
//}





























