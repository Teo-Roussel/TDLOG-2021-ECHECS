#include <pybind11/embed.h>
#include <pybind11/operators.h>
#include <pybind11/stl.h>
#include <pybind11/functional.h>
#include <pybind11/stl_bind.h>



#include <functional>
#include <iostream>

#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <map>
#include <vector>

PYBIND11_MAKE_OPAQUE(std::vector<int>);
PYBIND11_MAKE_OPAQUE(std::vector<std::string>);

#include <engine.h>
//#include <engine.cpp>
#include <piece.h>
//#include <piece.cpp>
#include <damier.h>
//#include <damier.cpp>


void print_coucou() {
    std::cout << "coucou ! " << std::endl;    
}


static int COUNTER = 0;

void set_counter(int x) {
    COUNTER = x;
}


struct MyData {
    float x;
};


PYBIND11_EMBEDDED_MODULE(embedded_module, module) {
    module.doc() = "La documentation de embedded_module";
    pybind11::bind_vector<std::vector<int>>(module, "VectorInt");
    pybind11::bind_vector<std::vector<std::string>>(module, "VectorString");

    module.def("print_coucou", &print_coucou);
    module.def("set_counter", &set_counter);
    pybind11::class_<MyData>(module, "MyData")
        .def_readwrite("x", &MyData::x);

    pybind11::class_<Piece>(module, "Piece")
        .def(pybind11::init<>())
        .def(pybind11::init<std::string, bool>(), "constructeur 2", pybind11::arg("piece_name"), pybind11::arg("is_white"))
        .def("getName", &Piece::getName)
        .def("isWhite", &Piece::isWhite)     
       
        .def_property_readonly("name", &Piece::getName)
        
        .def_property_readonly("is_white", &Piece::isWhite)
        .def("__repr__", [](const Piece& p) { return "pybind11module.Piece named " + ((p.getName() == "vide") ? "vide" : (p.isWhite() ? (p.getName() + " Blanc") : (p.getName() + " Noir"))); })
        .def("__str__", [](const Piece& p) { return ((p.getName() == "vide") ? "    v    " : (p.isWhite() ? (p.getName() + " Blanc") : (p.getName() + " Noir"))); })
        //.def("__repr__", &operator<<)
        //.def("__str__", &operator<<)
        ;

    pybind11::class_<Damier>(module, "Damier")
        .def(pybind11::init<>())        
        .def(pybind11::init<std::string>(), "constructeur 3", pybind11::arg("damier_fen"))
        .def("__call__", &Damier::operator())
        .def("display", &Damier::display)
        .def("setPieceOnSquare", &Damier::setPieceOnSquare, pybind11::arg("pos"), pybind11::arg("piece"))
        .def("isCastle", &Damier::isCastle, pybind11::arg("side"), pybind11::arg("is_player_white"))
        .def("forbidCastle", &Damier::forbidCastle, pybind11::arg("side"), pybind11::arg("is_player_white"))
        .def("allowCastle", &Damier::allowCastle, pybind11::arg("side"), pybind11::arg("is_player_white"))
        .def("getPlayerTurn", &Damier::getPlayerTurn)
        .def("isPieceEmpty", &Damier::isPieceEmpty, pybind11::arg("pos"))

        // rajouter les is_attacked ?
        .def("is_king_attacked", &Damier::is_king_attacked)

        .def("mvt_tour", &Damier::mvt_tour, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"))
        .def("mvt_fou", &Damier::mvt_fou, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"))
        .def("mvt_cavalier", &Damier::mvt_cavalier, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"))
        .def("mvt_dame", &Damier::mvt_dame, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"))
        .def("mvt_roi", &Damier::mvt_roi, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"), pybind11::arg("callIs_attacked"))
        .def("mvt_pion", &Damier::mvt_pion, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("promotion_vect"))


        .def("movement_piece", &Damier::movement_piece, pybind11::arg("pos"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("prom_vect"), pybind11::arg("callIs_attacked"))
        .def("player_possible_movements", &Damier::player_possible_movements, pybind11::arg("is_player_white"), pybind11::arg("pos_ini_vect"), pybind11::arg("pos_fin_vect"), pybind11::arg("prom_vect"), pybind11::arg("callIs_attacked"))
        .def("bouge_piece", &Damier::bouge_piece, pybind11::arg("pos_ini"), pybind11::arg("pos_fin"), pybind11::arg("promotion"))


        .def("add_move_to_stack", &Damier::add_move_to_stack, pybind11::arg("pos_ini"), pybind11::arg("pos_fin"), pybind11::arg("nbr_moves"))
        .def("undo_move", &Damier::undo_move)
        .def("generate_FEN", &Damier::generateFEN)
        ;

    module.def("alpha_beta_exploration", &alpha_beta_exploration);
}






int main()
{  
    pybind11::scoped_interpreter guard{};

    // separation

    pybind11::exec("print('hello world displayed in python, written in c++')"); // pour executer le python environment
    pybind11::exec("import embedded_module"); // importation du module SOUS PYTHON. Une fois faite, plus besoin de la faire dans la suite
    pybind11::exec("embedded_module.print_coucou()");
    pybind11::exec("embedded_module.set_counter(10)");
    
    int pos_ini = -1;
    int pos_fin = -1;
    std::string prom = "";
    cout << "============" << endl;
    //pybind11::exec("embedded_module.avecpruning(test_d, pos_ini, pos_fin, prom,5)");

    auto sys = pybind11::module::import("sys");
    pybind11::print(sys.attr("path"));

    auto hello_module = pybind11::module::import("hello");
    auto magic_function = hello_module.attr("magic");

    MyData data_test;
    data_test.x = 8.0;

    magic_function(&data_test);



    std::cout << COUNTER << std::endl;    
    return 0;
}
